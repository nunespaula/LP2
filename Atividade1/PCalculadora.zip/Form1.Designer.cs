﻿
namespace PCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Limpar = new System.Windows.Forms.Button();
            this.Sair = new System.Windows.Forms.Button();
            this.Divisão = new System.Windows.Forms.Button();
            this.Multiplicação = new System.Windows.Forms.Button();
            this.Subtração = new System.Windows.Forms.Button();
            this.Adição = new System.Windows.Forms.Button();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(97, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numero 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(97, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Numero 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(97, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Resultado";
            // 
            // Limpar
            // 
            this.Limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Limpar.Location = new System.Drawing.Point(493, 111);
            this.Limpar.Name = "Limpar";
            this.Limpar.Size = new System.Drawing.Size(167, 46);
            this.Limpar.TabIndex = 3;
            this.Limpar.Text = "Limpar";
            this.Limpar.UseVisualStyleBackColor = true;
            this.Limpar.Click += new System.EventHandler(this.button1_Click);
            // 
            // Sair
            // 
            this.Sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sair.Location = new System.Drawing.Point(493, 202);
            this.Sair.Name = "Sair";
            this.Sair.Size = new System.Drawing.Size(167, 46);
            this.Sair.TabIndex = 4;
            this.Sair.Text = "Sair";
            this.Sair.UseVisualStyleBackColor = true;
            this.Sair.Click += new System.EventHandler(this.Sair_Click);
            // 
            // Divisão
            // 
            this.Divisão.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Divisão.Location = new System.Drawing.Point(635, 326);
            this.Divisão.Name = "Divisão";
            this.Divisão.Size = new System.Drawing.Size(167, 46);
            this.Divisão.TabIndex = 5;
            this.Divisão.Text = "/";
            this.Divisão.UseVisualStyleBackColor = true;
            this.Divisão.Click += new System.EventHandler(this.Divisão_Click);
            // 
            // Multiplicação
            // 
            this.Multiplicação.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Multiplicação.Location = new System.Drawing.Point(436, 326);
            this.Multiplicação.Name = "Multiplicação";
            this.Multiplicação.Size = new System.Drawing.Size(167, 46);
            this.Multiplicação.TabIndex = 6;
            this.Multiplicação.Text = "*";
            this.Multiplicação.UseVisualStyleBackColor = true;
            this.Multiplicação.Click += new System.EventHandler(this.Multiplicação_Click);
            // 
            // Subtração
            // 
            this.Subtração.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Subtração.Location = new System.Drawing.Point(220, 326);
            this.Subtração.Name = "Subtração";
            this.Subtração.Size = new System.Drawing.Size(167, 46);
            this.Subtração.TabIndex = 7;
            this.Subtração.Text = "-";
            this.Subtração.UseVisualStyleBackColor = true;
            this.Subtração.Click += new System.EventHandler(this.Subtração_Click);
            // 
            // Adição
            // 
            this.Adição.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adição.Location = new System.Drawing.Point(12, 326);
            this.Adição.Name = "Adição";
            this.Adição.Size = new System.Drawing.Size(167, 46);
            this.Adição.TabIndex = 8;
            this.Adição.Text = "+";
            this.Adição.UseVisualStyleBackColor = true;
            this.Adição.Click += new System.EventHandler(this.Adição_Click);
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(220, 90);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(177, 20);
            this.txtNum1.TabIndex = 9;
            // 
            // txtNum3
            // 
            this.txtNum3.Enabled = false;
            this.txtNum3.Location = new System.Drawing.Point(220, 249);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(177, 20);
            this.txtNum3.TabIndex = 10;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(220, 160);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(177, 20);
            this.txtNum2.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.Adição);
            this.Controls.Add(this.Subtração);
            this.Controls.Add(this.Multiplicação);
            this.Controls.Add(this.Divisão);
            this.Controls.Add(this.Sair);
            this.Controls.Add(this.Limpar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Limpar;
        private System.Windows.Forms.Button Sair;
        private System.Windows.Forms.Button Divisão;
        private System.Windows.Forms.Button Multiplicação;
        private System.Windows.Forms.Button Subtração;
        private System.Windows.Forms.Button Adição;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.TextBox txtNum2;
    }
}

